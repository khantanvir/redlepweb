<?php

namespace App\Models\Application;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ApplicationIntake extends Model
{
    use HasFactory;
    public $table = "application_intakes";
}
