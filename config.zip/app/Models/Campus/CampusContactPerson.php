<?php

namespace App\Models\Campus;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CampusContactPerson extends Model
{
    use HasFactory;
    public $table = 'campus_contact_persons';
}
